<?php

  function return_balance()
  {
    include 'connection.php';
    $sql = "SELECT * FROM till";
    $result = $conn->query($sql);
    $sum = 0;
    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        $sum += $row["value"];
        //  echo "id: " . $row["id"]. " - Value: " . $row["value"]."<br>";
      }
    }
    return $sum;
  }


  function get_money_count($money){
    include 'connection.php';
    $sql = "SELECT * FROM till where value=".$money;
    $result = $conn->query($sql);
    $sum = 0;
    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        $sum ++;
      }
    }
    return $sum;
  }


  function type_of_money(){
    include 'connection.php';
    $sql = "SELECT DISTINCT value FROM till order by value desc";
    $result = $conn->query($sql);
    $type_money=array();
    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        array_push($type_money,$row["value"]);
      }
    }
    return $type_money;
  }


  function delete_money($money){
    include 'connection.php';
    $sql = "DELETE FROM till WHERE value='$money' ORDER BY id DESC LIMIT 1";
    $conn->query($sql);
  }




