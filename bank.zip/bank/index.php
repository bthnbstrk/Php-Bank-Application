<?php
  include_once 'functions.php';

  $total_money = return_balance();
  $types_money = type_of_money();

  $desired_amount = 100;

  echo "<h1>" . "Kasadaki Para: " . $total_money . " TL </h1>";
  echo "<h1>" . "Çekilmek istenen tutar: " . $desired_amount . " TL</h1>" . "<br>";
  $messages = array();
  $remove_array = array();

  if ($desired_amount > $total_money) {
    echo "<h4 style='color: red'>" . "Üzgünüm kasada bu kadar para yok" . "</h4>";
  } else {
    for ($i = 0; $i < count($types_money); $i++) {
      if ($desired_amount < $types_money[$i]) {
        continue;
      } else {
        $count_money = floor($desired_amount / $types_money[$i]);
        if ($count_money <= get_money_count($types_money[$i])) {
          $desired_amount = $desired_amount - $count_money * $types_money[$i];
          $remove_money = [$count_money, $types_money[$i]];
          $str = $count_money . " adet " . $types_money[$i] . " ₺ verildi" . "<br>";
          array_push($messages, $str);
          array_push($remove_array, $remove_money);
        } else {
          $desired_amount = $desired_amount - get_money_count($types_money[$i]) * $types_money[$i];
          $str = get_money_count($types_money[$i]) . " adet " . $types_money[$i] . " tl verildi" . "<br>";
          $remove_money = [get_money_count($types_money[$i]), $types_money[$i]];
          array_push($messages, $str);
          array_push($remove_array, $remove_money);
        }
      }
    }

  }

  if ($desired_amount == 0) {
    foreach ($messages as $message) {
      echo "<h4 style='color: green'>" . $message . "</h4>";
    }
    for ($i = 0; $i < count($remove_array); $i++) {
      while ($remove_array[$i][0] > 0) {
        delete_money($remove_array[$i][1]);
        $remove_array[$i][0]--;
      }
    }
  } else {
    echo "<h4 style='color: red'>" . "İşleminiz gerçekleştirilemedi !!!" . "</h4>";
  }
